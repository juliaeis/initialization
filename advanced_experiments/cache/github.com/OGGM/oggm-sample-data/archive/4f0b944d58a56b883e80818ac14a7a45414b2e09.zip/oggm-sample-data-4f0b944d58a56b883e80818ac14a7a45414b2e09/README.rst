.. -*- rst -*- -*- restructuredtext -*-
.. This file should be written using restructured text conventions

================
OGGM sample data
================

Reference data for testing and demos.


About
-----

:License:
    GNU GPLv3

:Author:
    Fabien Maussion
